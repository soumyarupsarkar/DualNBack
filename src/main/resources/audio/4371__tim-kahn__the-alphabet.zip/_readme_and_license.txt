Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - tim.kahn ( https://freesound.org/people/tim.kahn/ )

You can find this pack online at: https://freesound.org/people/tim.kahn/packs/4371/

License details
---------------

Attribution: http://creativecommons.org/licenses/by/3.0/


Sounds in this pack
-------------------

  * 67737__Corsica_S__z.wav
    * url: https://freesound.org/s/67737/
    * license: Attribution
  * 67736__Corsica_S__y.wav
    * url: https://freesound.org/s/67736/
    * license: Attribution
  * 67735__Corsica_S__x.wav
    * url: https://freesound.org/s/67735/
    * license: Attribution
  * 67734__Corsica_S__w.wav
    * url: https://freesound.org/s/67734/
    * license: Attribution
  * 67733__Corsica_S__v.wav
    * url: https://freesound.org/s/67733/
    * license: Attribution
  * 67732__Corsica_S__u.wav
    * url: https://freesound.org/s/67732/
    * license: Attribution
  * 67731__Corsica_S__t.wav
    * url: https://freesound.org/s/67731/
    * license: Attribution
  * 67729__Corsica_S__r.wav
    * url: https://freesound.org/s/67729/
    * license: Attribution
  * 67730__Corsica_S__s.wav
    * url: https://freesound.org/s/67730/
    * license: Attribution
  * 67728__Corsica_S__q.wav
    * url: https://freesound.org/s/67728/
    * license: Attribution
  * 67727__Corsica_S__p.wav
    * url: https://freesound.org/s/67727/
    * license: Attribution
  * 67726__Corsica_S__o.wav
    * url: https://freesound.org/s/67726/
    * license: Attribution
  * 67725__Corsica_S__n.wav
    * url: https://freesound.org/s/67725/
    * license: Attribution
  * 67724__Corsica_S__m.wav
    * url: https://freesound.org/s/67724/
    * license: Attribution
  * 67723__Corsica_S__l.wav
    * url: https://freesound.org/s/67723/
    * license: Attribution
  * 67722__Corsica_S__k.wav
    * url: https://freesound.org/s/67722/
    * license: Attribution
  * 67721__Corsica_S__j.wav
    * url: https://freesound.org/s/67721/
    * license: Attribution
  * 67720__Corsica_S__i.wav
    * url: https://freesound.org/s/67720/
    * license: Attribution
  * 67718__Corsica_S__g.wav
    * url: https://freesound.org/s/67718/
    * license: Attribution
  * 67719__Corsica_S__h.wav
    * url: https://freesound.org/s/67719/
    * license: Attribution
  * 67717__Corsica_S__f.wav
    * url: https://freesound.org/s/67717/
    * license: Attribution
  * 67715__Corsica_S__d.wav
    * url: https://freesound.org/s/67715/
    * license: Attribution
  * 67716__Corsica_S__e.wav
    * url: https://freesound.org/s/67716/
    * license: Attribution
  * 67714__Corsica_S__c.wav
    * url: https://freesound.org/s/67714/
    * license: Attribution
  * 67713__Corsica_S__b.wav
    * url: https://freesound.org/s/67713/
    * license: Attribution
  * 67712__Corsica_S__a.wav
    * url: https://freesound.org/s/67712/
    * license: Attribution


